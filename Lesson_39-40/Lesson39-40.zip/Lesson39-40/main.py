import sqlite3
from random import randint

db = sqlite3.connect("User.db")
sql = db.cursor()  # Взаимодействие с таблицей
sql.execute("""CREATE TABLE IF NOT EXISTS User(
    login TEXT,
    password TEXT,
    cash INT
)""")
db.commit()


def reg():
    user_login = input("Введите логин: ")
    user_password = input("Введите пароль: ")
    sql.execute(f"SELECT login FROM User WHERE login = '{user_login}'")
    if sql.fetchone() is None:
        sql.execute(f"INSERT INTO User VALUES(?, ?, ?)", (user_login, user_password, 0))
        db.commit()
        print("Зарегестрировано!")
    else:
        print("Такая учётная запись уже существует!")
    for i in sql.execute("SELECT * FROM User"):
        print(i)
    casino()


def game_one_to_three():
    number = randint(1, 3)
    global user_log
    rand_att = int(input("Угадайте число от 1 до 3: "))
    if rand_att == number:
        sql.execute(f"UPDATE user SET cash = {10 + result} WHERE login = '{user_log}'")
        print("Вы выиграли!")
        for i in sql.execute("SELECT * FROM User"):
            print(i)
    else:
        print(f"Вы не угадали!")
        again = input(
            f"Если хотите попробовать ещё раз, напишите a! Если хотите завершить игру, введите любой иной символ!\n~~~ ")
        if again == "a":
            game_one_to_three()
        else:
            print("Спасибо за игру!")
            casino()


def more_less():
    number = randint(0, 100)
    print(f"Первое число - {number}")
    m_or_l = input("Второе число будет больше(`больше`), меньше(`меньше`) или равно(`равно`): ")
    number_two = randint(0, 100)

    for i in sql.execute(f"SELECT cash FROM User WHERE  login = '{user_log}'"):
        result = i[0]

    if number_two > number and m_or_l == "больше":
        sql.execute(f"UPDATE user SET cash = {10 + result} WHERE login = '{user_log}'")
        print("Вы выиграли!")
        for i in sql.execute("SELECT * FROM User"):
            print(i)
            again = input(f"Если хотите попробовать ещё раз, напишите a! Если хотите завершить игру, введите любой иной символ!\n~~~ ")
            if again == "a":
                more_less()
            else:
                print("Спасибо за игру!")
                casino()
    elif number_two == number and m_or_l == "равно":
        sql.execute(f"UPDATE user SET cash = {10 + result} WHERE login = '{user_log}'")
        print("Вы выиграли!")
        for i in sql.execute("SELECT * FROM User"):
            print(i)
        again = input(f"Если хотите попробовать ещё раз, напишите a! Если хотите завершить игру, введите любой иной символ!\n~~~ ")
        if again == "a":
            more_less()
        else:
            print("Спасибо за игру!")
            casino()
    elif number_two < number and m_or_l == "меньше":
        sql.execute(f"UPDATE user SET cash = {10 + result} WHERE login = '{user_log}'")
        print("Вы выиграли!")
        for i in sql.execute("SELECT * FROM User"):
            print(i)
        again = input(f"Если хотите попробовать ещё раз, напишите a! Если хотите завершить игру, введите любой иной символ!\n~~~ ")
        if again == "a":
            more_less()
        else:
            print("Спасибо за игру!")
            casino()
    else:
        sql.execute(f"UPDATE user SET cash = {result - 15} WHERE login = '{user_log}'")
        print(f"Вы не угадали!")
        for i in sql.execute("SELECT * FROM User"):
            print(i)
        again = input(f"Если хотите попробовать ещё раз, напишите a! Если хотите завершить игру, введите любой иной символ!\n~~~ ")
        if again == "a":
            more_less()
        else:
            print("Спасибо за игру!")
            casino()

def casino():
    global user_log
    user_log = input("Введите логин: ")
    sql.execute(f"SELECT login FROM User WHERE login = '{user_log}'")

    if sql.fetchone() is None:
        print("Вас нет в системе! Зарегестрируйтесь, чтобы играть!")
        reg()
    else:
        print("Такая учётная запись существует! Можете играть, удачи)")
        while True:
            print(f"Игры: \n---Number guessing(`n`)\n---More or Less(`ML`)")
            choise_game = input("Выберите во что сыграем: ")
            if choise_game == "n":
                game_one_to_three()
            elif choise_game == "ML":
                more_less()
            else:
                for i in sql.execute("SELECT * FROM User"):
                    print(i)
                casino()
