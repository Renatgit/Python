import math
# p = 3.14
# r = int(input("Введите радиус круга: "))
#
#
# if r >= 0:
#     s = p * r * r
#     c = 2 * p * r
#     print(f"Площадь круга: {s}\nДлинна окружности: {c}")
# else:
#     print("Радиус круга не может быть меньше нуля!")
#Ex.1, task1



# password = input("Придумайте пароль: ")
# password_check = input("Подтвердите пароль: ")
#
# if password_check == password:
#     print("Пароль сохранён!")
# else:
#     print("Пароль не подтвержен! Вы ввели его не правильно.")
#Ex.2, task1



# age = int(input("Введите свой возраст: "))
# if age >= 18:
#     print("Вы имеете право на кредит!")
# elif 0 <= age < 18:
#     print("Вы ещё не достигли возраста для получения кредита!")
# else:
#     print("Возраст не может быть меньше нуля!")
#Ex.3, task1



# mark = int(input("Введите оценку ученика: "))
# if 0 < mark <= 3:
#     print("Низкий уровень!")
# elif 4 <= mark <= 6:
#     print("Средний уровень!")
# elif 7 <= mark <= 9:
#     print("Достаточный уровень!")
# elif 10 <= mark <= 12:
#     print("Высокий уровень!")
# elif mark > 12:
#     print("Оценка не может быть больше 12 баллов!")
# else:
#     print("Оценка не может быть меньше 1!")
#Ex.4, task1




#
# x = int(input("Введите число х: "))
# y = int(input("Введите число y: "))
# if x > y:
#     z = math.sqrt(x*y)
#     print(f"Z = {z}")
# else:
#     z = math.log2(x+y)
#     print(f"Z = {z}")
#Ex.5, task1



# t = int(input("Введите температуру: "))
# if t > 20:
#     print("On")
# else:
#     print("Off")
#Ex.6, task1



# n = int(input("Каким по счёту стоит Вася: "))
# if n > 0:
#     if n % 2 == 0:
#         print("Вася скажет: `второй`")
#     else:
#         print("Вася скажет: `первый`")
# else:
#     print("Неправильная позиция!")
#Ex.7, task1



# a = int(input("Введите первую сторону треугольника: "))
# b = int(input("Введите вторую сторону треугольника: "))
# c = int(input("Введите трутью сторону треугольника: "))
# if a > 0 and b > 0 and c > 0:
#     if a + b > c:
#         if a == b != c or a == c != b or b == c != a:
#             print("Такой треугольник существует! Это равнобедренный треугольник!")
#         elif a == b == c:
#             print("Такой треугольник существует! Это равносторонний треугольник!")
#         else:
#             print("Такой треугольник существует! Это разносторонний треугольник!")
#     else:
#         print("Такого треугольника не существует!")
# else:
#     print("Сторона не может быть равна или меньше нуля!")
#Ex.8, task1



# x = int(input('Введите значение х: '))
#
# if x+5 >= 0:
#     y = math.sqrt(x + 5)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# Ex.1, task.2



# x = int(input('Введите значение х: '))
#
# if x-7 != 0:
#     y = 1/(x - 7)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.2, task.2




# x = int(input('Введите значение х: '))
#
# if x+5 > 0:
#     y = 1/math.sqrt(x + 5)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.3, task.2



# x = int(input('Введите значение х: '))
#
# if x+5 != 0:
#     y = 1/abs(x + 5)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.4, task.2



# x = int(input('Введите значение х: '))
#
# if x != 0:
#     y = 1/x**7
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.5, task.2



# x = int(input('Введите значение х: '))
#
# if x+5 >= 0 and x-7 >= 0:
#     y = math.sqrt(x + 5)+math.sqrt(x-7)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.6, task.2



# x = int(input('Введите значение х: '))
#
# if x+5 >= 0 and x-7 != 0:
#     y = math.sqrt(x + 5)+1/(x-7)
#     print(y)
# else:
#     print('Функция не имеет решений!')
#  Ex.7, task.2



# x = int(input('Введите значение х: '))
#
# if x+5 > 0 and x-7 != 0:
#     y = 1/math.sqrt(x + 5)+1/(x-7)
#     print(y)
# else:
#     print('Функция не имеет решений!')
# # Ex.8, task.2



# x = int(input('Введите значение х: '))
#
# if x > 0:
#     y = x
#     print(f'y = {y}')
# else:
#     y = x**2
#     print(f'y = {y}')
# # Ex.1, task.3



# x = int(input('Введите значение х: '))
#
# if -10 < x < 5:
#     y = x
#     print(f'y = {y}')
# else:
#     y = x**2
#     print(f'y = {y}')
# #  Ex.2, task.3



# x = int(input('Введите значение х: '))
#
# if 1 <= x <= 5 or x >= 10:
#     y = x
#     print(f'y = {y}')
# else:
#     y = x**2
#     print(f'y = {y}')
# # Ex.3, task.3



# x = int(input('Введите значение х: '))
#
# if x <= 0:
#     y = x
#     print(f'y = {y}')
# elif 0 < x <= 5:
#     y = x**2
#     print(f'y = {y}')
# else:
#     y = 25
#     print(f'y = {y}')
# # Ex.4, task.3