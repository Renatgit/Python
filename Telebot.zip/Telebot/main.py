from unittest.mock import call

import telebot
from telebot import types

bot = telebot.TeleBot("5215684920:AAFXmGhSjuvk3uzI5H01Wlj4_I5Dwa_VapY", parse_mode=None)

name=""
surname=""
age=0
country=""
city=""
education=""
eng_edu=""
exp=0
wage=0



@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message,
                 "Здравствуйте, я персональный бот компании `Name`. Нажмите /help, если хотите узнать все команды бота.")


@bot.message_handler(commands=['vac'])
def vacancies(message):
    bot.reply_to(message, f"Свободдные вакансии:"
                          f"\nВеб-разработчик - /web_dev"
                          f"\nBackend-разработчик - /back_dev"
                          f"\nFrontend-разработчик - /front_dev"
                          f"\nВеб-дизайнер - /web_des"
                          f"\nТестировщик - /tester")

@bot.message_handler(commands=['web_dev'])
def vacancy_webdev(message):
    webdev_choice = f"Вы выбрали вакансию веб-разарботчика!" \
                    f"\nХотите узнать обязанности веб-разработчика или сразу приступить к заполнению резюме?"
    button = types.InlineKeyboardMarkup()
    button_webdev_choice_duties = types.InlineKeyboardButton(text="Обязанности", callback_data="Обязанности_webdev")
    button_choice_summary = types.InlineKeyboardButton(text="Резюме", callback_data="Резюме")
    button.add(button_webdev_choice_duties, button_choice_summary)
    bot.send_message(message.from_user.id, text=webdev_choice, reply_markup=button)

@bot.message_handler(commands=['back_dev'])
def vacancy_back_dev(message):
    backdev_choice = f"Вы выбрали вакансию Backend-разарботчика!" \
                    f"\nХотите узнать обязанности Backend-разработчика или сразу приступить к заполнению резюме?"
    button = types.InlineKeyboardMarkup()
    button_backdev_choice_duties = types.InlineKeyboardButton(text="Обязанности", callback_data="Обязанности_backdev")
    button_choice_summary = types.InlineKeyboardButton(text="Резюме", callback_data="Резюме")
    button.add(button_backdev_choice_duties, button_choice_summary)
    bot.send_message(message.from_user.id, text=backdev_choice, reply_markup=button)

@bot.message_handler(commands=['front_dev'])
def vacancy_front_dev(message):
    frontdev_choice = f"Вы выбрали вакансию Frontend-разарботчика!" \
                    f"\nХотите узнать обязанности Frontend-разработчика или сразу приступить к заполнению резюме?"
    button = types.InlineKeyboardMarkup()
    button_frontdev_choice_duties = types.InlineKeyboardButton(text="Обязанности", callback_data="Обязанности_frontdev")
    button_choice_summary = types.InlineKeyboardButton(text="Резюме", callback_data="Резюме")
    button.add(button_frontdev_choice_duties, button_choice_summary)
    bot.send_message(message.from_user.id, text=frontdev_choice, reply_markup=button)

@bot.message_handler(commands=['web_des'])
def vacancy_web_des(message):
    webdes_choice = f"Вы выбрали вакансию веб-дизайнера!" \
                    f"\nХотите узнать обязанности веб-дизайнера или сразу приступить к заполнению резюме?"
    button = types.InlineKeyboardMarkup()
    button_webdes_choice_duties = types.InlineKeyboardButton(text="Обязанности", callback_data="Обязанности_webdes")
    button_choice_summary = types.InlineKeyboardButton(text="Резюме", callback_data="Резюме")
    button.add(button_webdes_choice_duties, button_choice_summary)
    bot.send_message(message.from_user.id, text=webdes_choice, reply_markup=button)

@bot.message_handler(commands=['tester'])
def vacancy_tester(message):
    tester_choice = f"Вы выбрали вакансию тестировщика!" \
                    f"\nХотите узнать обязанности тестировщика или сразу приступить к заполнению резюме?"
    button = types.InlineKeyboardMarkup()
    button_tester_choice_duties = types.InlineKeyboardButton(text="Обязанности", callback_data="Обязанности_tester")
    button_choice_summary = types.InlineKeyboardButton(text="Резюме", callback_data="Резюме")
    button.add(button_tester_choice_duties, button_choice_summary)
    bot.send_message(message.from_user.id, text=tester_choice, reply_markup=button)

@bot.message_handler(commands=['help'])
def send_help(message):
    bot.reply_to(message, f"Вот все команды бота:\n/start - запуск бота!\n/vac - свободные вакансии!")


@bot.message_handler(func=lambda m: True)
def echo_all(message):
    bot.reply_to(message, "Здравствуйте, я персональный бот компании `Name`. Нажмите /help, если хотите узнать все команды бота.")


@bot.callback_query_handler(func=lambda call: True)
def callback_hadler(call):
    if call.data == "Резюме":
        bot.send_message(call.message.chat.id, f"Здравствуйте! Давайте начнём заполнение резюме.")
        bot.send_message(call.message.chat.id, f"Как вас зовут?")
        bot.register_next_step_handler(call.message, registr_name)

    elif call.data == "Обязанности_webdev":
        bot.send_message(call.message.chat.id, f"Обязанности веб-разрабобтчика:"
                                               f"\n~~~Создавать веб-сайты;"
                                               f"\n~~~Следить за слаженной работой программного обеспечения (далее ПО);"
                                               f"\n~~~Оптимизировать веб-сайты под мобильные условия;"
                                               f"\n~~~Поддерживать ресурс в рабочем состоянии, обновлять ПО, устанавливать новые элементы на сайт;"
                                               f"\n~~~Время работы: 30-40 часов в неделю"
                                               f"\n~~~Зарплата: почасовая"
                                               f"\nЕсли вас устраивают обязанности веб-разаработчика, то можете приступить к заполнению резюме /web_dev! Если вас интересуют другие вакансии нажмите /vac")
    elif call.data == "Обязанности_backdev":
        bot.send_message(call.message.chat.id, f"Обязанности Backend-разрабобтчика:"
                                               f"\n~~~Проектирование архитектуры сервиса;"
                                               f"\n~~~Создание ядра сайта;"
                                               f"\n~~~Разработка платформы и основного функционала;"
                                               f"\n~~~Работа с архитектурой кода;"
                                               f"\n~~~Время работы: 30-40 часов в неделю"
                                               f"\n~~~Зарплата: почасовая"
                                               f"\nЕсли вас устраивают обязанности Backend-разаработчика, то можете приступить к заполнению резюме /back_dev! Если вас интересуют другие вакансии нажмите /vac")
    elif call.data == "Обязанности_frontdev":
        bot.send_message(call.message.chat.id, f"Обязанности Frontend-разрабобтчика:"
                                               f"\n~~~Адаптивная и кросс-браузерная верстка сайтов;"
                                               f"\n~~~Доработка существующих проектов, повышение их удобства;"
                                               f"\n~~~Создание реактивных компонентов, написание скриптов;"
                                               f"\n~~~Поддержка и развитие текущей архитектуры на основе виджетов и компонентов;"
                                               f"\n~~~Время работы: 30-40 часов в неделю"
                                               f"\n~~~Зарплата: почасовая"
                                               f"\nЕсли вас устраивают обязанности Frontend-разаработчика, то можете приступить к заполнению резюме /front_dev! Если вас интересуют другие вакансии нажмите /vac")
    elif call.data == "Обязанности_webdes":
        bot.send_message(call.message.chat.id, f"Обязанности веб-дизайнера:"
                                               f"\n~~~Придумывание дизайна сайтов, отдельных страниц, e-mail рассылок;"
                                               f"\n~~~Отрисовка макетов сайтов или отдельных его страниц;"
                                               f"\n~~~Создание иконок, иллюстраций для сайтов, баннеров;"
                                               f"\n~~~Время работы: 30-40 часов в неделю"
                                               f"\n~~~Зарплата: почасовая"
                                               f"\nЕсли вас устраивают обязанности веб-дизайнера, то можете приступить к заполнению резюме /web_des! Если вас интересуют другие вакансии нажмите /vac")
    elif call.data == "Обязанности_tester":
        bot.send_message(call.message.chat.id, f"Обязанности тестировщика:"
                                               f"\n~~~Контроль качества разрабатываемых продуктов;"
                                               f"\n~~~Выявление и анализ ошибок и проблем, возникающих у пользователей при работе с программными продуктами;"
                                               f"\n~~~Разработка автотестов и их регулярный прогон;"
                                               f"\n~~~Разработка сценариев тестирования;"
                                               f"\n~~~Документирование найденных дефектов;"
                                               f"\n~~~Время работы: 30-40 часов в неделю"
                                               f"\n~~~Зарплата: почасовая"
                                               f"\nЕсли вас устраивают обязанности тестировщика, то можете приступить к заполнению резюме /tester! Если вас интересуют другие вакансии нажмите /vac")
    elif call.data == "Да":
        bot.send_message(call.message.chat.id, f"Хорошо, ваше резюме отправлено менеджеру по подбору персонала.\nЕсли хотите просмотреть другие возможности бота нажмите /help")
    elif call.data == "Нет":
        bot.send_message(call.message.chat.id, "Тогда снова заполните форму снова! Как вас зовут?")
        bot.register_next_step_handler(call.message, registr_name)


def registr_name(call):
    global name
    name=call.text
    bot.send_message(call.from_user.id, "Введите вашу фаимилию: ")
    bot.register_next_step_handler(call, registr_surname)

def registr_surname(call):
    global surname
    surname=call.text
    bot.send_message(call.from_user.id, "Введите ваш возраст: ")
    bot.register_next_step_handler(call, registr_age)

def registr_age(call):
    global age
    age=call.text
    bot.send_message(call.from_user.id, "Введите страну проживания: ")
    bot.register_next_step_handler(call, registr_country)

def registr_country(call):
    global country
    country=call.text
    bot.send_message(call.from_user.id, "Введите город проживания: ")
    bot.register_next_step_handler(call, registr_city)

def registr_city(call):
    global city
    city=call.text
    bot.send_message(call.from_user.id, "Введите ваш уровень английского: ")
    bot.register_next_step_handler(call, registr_eng)

def registr_eng(call):
    global eng_edu
    eng_edu=call.text
    bot.send_message(call.from_user.id, "Введите ваше образование: ")
    bot.register_next_step_handler(call, registr_education)

def registr_education(call):
    global education
    education=call.text
    bot.send_message(call.from_user.id, "Введите стаж работы в данном направлении: ")
    bot.register_next_step_handler(call, registr_exp)

def registr_exp(call):
    global exp
    exp=call.text
    bot.send_message(call.from_user.id, "Введите желаемую заработную плату(в $): ")
    bot.register_next_step_handler(call, registr_wage)

def registr_wage(call):
    global wage
    wage=call.text
    button = types.InlineKeyboardMarkup()
    button_yes = types.InlineKeyboardButton(text="Да", callback_data="Да")
    button_no = types.InlineKeyboardButton(text="Нет", callback_data="Нет")
    button.add(button_yes, button_no)
    bot.send_message(call.from_user.id, text=f"Ваше резюме:\n"
                                             f"Имя: {name}\n"
                                             f"Фамилия: {surname}\n"
                                             f"Возраст: {age}\n"
                                             f"Страна проживания: {country}\n"
                                             f"Город: {city}\n"
                                             f"Образование: {education}\n"
                                             f"Уровень английского языка: {eng_edu}\n"
                                             f"Стаж: {exp}\n"
                                             f"Желаемая зарплата: {wage}$\n"
                                             f"Всё верно?", reply_markup=button)

bot.infinity_polling()
