import telebot
from telebot import types

bot = telebot.TeleBot("5145268027:AAHKkkAovLVwHJJGcxTnkhfQ7Xhim1PXiwg", parse_mode=None)
name=""
surname=""
age=0

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
	bot.reply_to(message, "Я твой персональный бот, давай познакомимся")

@bot.message_handler(func=lambda m: True)
def echo_all(message):
#bot.reply_to(message, "Привет")
    if message.text == "Привет":
        bot.reply_to(message, "Привет, я рад тебя видеть!")
    elif message.text == "/reg":
        bot.send_message(message.from_user.id, "Привет, давай познакомимся) Как тебя зовут?")
        bot.register_next_step_handler(message, registr_name)
    else:
        bot.reply_to(message, "Я вас не понимаю...")

def registr_name(message):
    global name
    name=message.text
    bot.send_message(message.from_user.id, "Введите вашу фаимилию:")
    bot.register_next_step_handler(message, registr_surname)
def registr_surname(message):
    global surname
    surname=message.text
    bot.send_message(message.from_user.id, "Введите ваш возраст:")
    bot.register_next_step_handler(message, registr_age)
def registr_age(message):
    global age
    while age==0:
        try:
            age=int(message.text)
        except Exception:
            bot.send_message(message.from_user.id, "Введите свой возраст числами: ")
    value = f"Я понял, что тебя зовут {name} {surname}. Тебе {age}, верно ли?"
    button = types.InlineKeyboardMarkup()
    button_yes = types.InlineKeyboardButton(text="Да", callback_data="Да")
    button_no = types.InlineKeyboardButton(text="Нет", callback_data="Нет")
    button.add(button_yes, button_no)
    #button.add(button_no)
    bot.send_message(message.from_user.id, text=value, reply_markup=button)

@bot.callback_query_handler(func=lambda call: True)
def callback_hadler(call):
    if call.data == "Да":
        bot.send_message(call.message.chat.id, "Хорошо, я записал вас в систему!")
    elif call.data == "Нет":
        bot.send_message(call.message.chat.id, "Тогда снова заполните форму снова! Как тебя зовут?")
        bot.register_next_step_handler(call.message, registr_name)

bot.infinity_polling()