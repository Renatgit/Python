# names = ['Den', 'Renat', 'Kirill']
# print(names[0])
# print(names[1])
# print(names[2])
# #Ex.1



# machines = ['велосипед', 'машиина', 'самолёт', 'яхта', 'самокат']
# for i in machines:
#     print(f'Я бы хотел купить такое транспортное средство, как {i}!')
#
# #Ex.2




# year_list = []
# year_birth = int(input('Введите год ващего рождения: '))
# year_to_list = year_birth
# while year_to_list <= year_birth + 5:
#     year_list.append(year_to_list)
#     year_to_list += 1
#
# print(year_list)
#
# for i in year_list:
#     if i-year_birth == 3:
#         print(f'В {i} году вам было 3 года!')
#     else:
#         continue
#
# #Ex.3




# things = ['wallet', 'mirror', 'umbrella']
#
# print(things[-1].title())
# print(things)
#
# things[-1] = things[-1].upper()
# print(things)
#
# del things[-1]
# print(things)
#
# #Ex.4



# languages = ['Geaorgian', 'Estonian', 'Ukrainian']
#
# print(languages)
#
# languages[-1] = languages[-1].lower()
# print(languages)
#
# languages[-1] = languages[-1][::-1]
# languages[-1] = languages[-1].title()
# print(languages)
#
# #Ex.5



# hardware = ('video card', 'monitor', 'keyboard')
# software = ['Windows', 'Antivirus']
#
# print('Кортеж: ')
# for i in hardware:
#     print(f'~~~{i.title()}')
#
# print('Список: ')
# for i in software:
#     print(f'~~~{i.title()}')
#
# #Ex.6



# languauges = ['Ukrainian', 'French', 'Bulgarian', 'Norwegian', 'Latvian']
#
# print(f'Default list: {languauges}')
#
# print(f'Sorted list: {sorted(languauges)}')
#
# print(f'Reversed list: {reversed(languauges)}')
#
# languauges = languauges.sort()
# print(f'Sort list: {languauges}')
#
# #Ex.7



# a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
#
# print('Элементы меньше 5: ')
# for i in a:
#     if i < 5:
#         print('~', i)
#     else:
#         continue
#
# #Ex.9



# year_of_birth = int(input('Введите год вашего рождения: '))
# year_now = 2022
# year_list = []
#
# while year_of_birth <= year_now:
#     year_list.append(year_of_birth)
#     year_of_birth+=1
# print(year_list)
# #Ex.10