import sqlite3
db=sqlite3.connect("User.db")
sql=db.cursor()
sql.execute("""CREATE TABLE IF NOT EXISTS user(
    login TEXT,
    password TEXT,
    cash INT
)""")
db.commit()
login_user = input("Login: ")
password_user = input("Password: ")
sql.execute(f"SELECT login FROM user WHERE login='{login_user}'")


if sql.fetchone() is None:
    sql.execute(f"INSERT INTO user VALUES (?, ?, ?)", (login_user, password_user, 0))
    db.commit()
    print("Вы зарегестрированы!")
else:
    print("Такая учётная запись уже существует!")
    print("Уже сущестсвуюцие учётные записи:")
    for i in sql.execute("SELECT * FROM user"):
        print(i)