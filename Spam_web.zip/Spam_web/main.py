import pyautogui, time

n = int(input("Введите количество повторений: "))
if n >0:
    print("Значение принято, через 5 секунд начнется спам, приготовтесь!")
    time.sleep(5); f = open("text.txt", "r")
    line_type = ""
    for line in f:
        line_type += line

    for i in range(n):
        pyautogui.typewrite(line_type)
        pyautogui.press("enter")
else:
    print("Значение должно быть больше нуля!")


